public class Main2 {
    public static void main(String[] args) {
        Coche miCoche = new Coche();
        miCoche.ponerPuerta();
        System.out.println(miCoche.Puertas);
    }
}

class Coche {
    public int Puertas = 3;

    public void ponerPuerta() {
        this.Puertas++;
    }
}